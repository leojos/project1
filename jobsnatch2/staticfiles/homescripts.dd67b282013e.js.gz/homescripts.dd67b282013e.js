// window.onscroll = function() {headFunction()};
      
//       var header1 = document.getElementById("myHeader");
//       var sticky = header1.offsetTop;
      
//       function headFunction() {
//         if (window.pageYOffset > sticky) {
//           header1.classList.add("sticky");
//         } else {
//           header1.classList.remove("sticky");
//         }
//       }



      // function candFunction() {
      //   document.getElementById('cand').style.display='block';
      //   document.getElementById('comp').style.display='none';
      //   document.getElementById('cand1').style.backgroundColor = "#000000";
      //   document.getElementById('comp1').style.backgroundColor = "rgb(8, 113, 10)";
      // }
      // function compFunction() {
      //   document.getElementById('comp').style.display='block';
      //   document.getElementById('cand').style.display='none';
      //   document.getElementById('comp1').style.backgroundColor = "#000000";
      //   document.getElementById('cand1').style.backgroundColor = "rgb(8, 113, 10)";
      // }
      // function callFunction() {
      //   document.getElementById('id01').style.display='block';
      //   document.getElementById('cand1').style.backgroundColor = "#000000";
      // }


      // Get the modal
      // var modal = document.getElementById('id02');
      
      // // When the user clicks anywhere outside of the modal, close it
      // window.onclick = function(event) {
      //   if (event.target == modal) {
      //     modal.style.display = "none";
      //   }
      // }